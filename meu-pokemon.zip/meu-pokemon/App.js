import { StatusBar } from 'expo-status-bar';
import { StyleSheet, Text, View } from 'react-native';
import Pokemon from './Components/Pokemon';

export default function App() {
  return (
    <View style={styles.container}>
      <Text>Olá, seja Bem-Vindo!</Text>
      <StatusBar style="auto" />
      <Pokemon></Pokemon>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
});
