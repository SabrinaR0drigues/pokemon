import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet } from 'react-native';

const Pokemon = () => {
const [pokemon, setPokemon] = useState(null);

useEffect(() => {
const fetchPokemon = async () => {
try {
const pokemon_aux = await fetch('https://pokeapi.co/api/v2/pokemon/pikachu');
const data = await pokemon_aux.json();
setPokemon(data);
console.log(data);
} catch (error) {
console.error('Erro ao buscar pokemon:', error);
}
};

fetchPokemon();
}, []);

return (
<View>
<Text>Pokemon</Text>

{pokemon?.name},
{pokemon?.id},
{pokemon?.species.url},

</View>
);
};

export default Pokemon;